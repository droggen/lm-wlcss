%% ifindpeak_step
% 
% Incrementally find a local optima
%
% Input:
% - curscore:   current sample of the stream in which to find local optima
% - st:         status variables
%
% Output:
% - st:         updated status variables
% - ret:        1x2 row vector. The second entry is 1 to indicate a local
%               optima, 0 otherwise. The first entry is the value of the local optima. 
%               Note that a local optima is detected after a latency equal to the search
%               window size.

function [st,ret]=ifindpeak_step(curscore,st)

if st.active==1
   st.k=st.k+1;                     % Count how far from peak
end

if curscore>st.lastscore           % Positive slope
    if curscore>st.curmax;          % Higher than current max in window
        st.curmax=curscore;         % Save max
        st.active=1;                % Flag we've a peak
        st.k=0;                     % count...
    end
end


if st.active==1 && st.k>=(st.window-1) && st.curmax>=st.thrd
    ret = [st.curmax 1];    
    st.active=0;
    st.curmax=realmin;
else
    ret = [realmin 0];
end


st.lastscore=curscore;

