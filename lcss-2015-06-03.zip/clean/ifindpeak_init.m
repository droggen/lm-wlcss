
function st=ifindpeak_init(threshold,winsize)
st=struct;
st.window=uint16(winsize);   %window size (this variable can be removed for code improvement)
st.k=uint8(1);    %counter for the window
st.thrd=int16(threshold);    %threshold value
st.active=uint8(0);   %The window is active or not, could be a bit-long variable
st.lastscore = int16(-1000);
st.curmax = int16(-1000);           % Current maximum (lowest value)
end
