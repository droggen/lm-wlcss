

function ret=findpeak(match,window,threshold)
sp=uint16(1);   %index for identification of peaks
k=uint16(1);    %counter for the window
a=1;
active=0;
for i=3:length(match)
    group(a,1)=match(end,i-1);
    if match(end,i)> match(end,i-1) %Positive slope
        if match(end,i)> max(group(:,1))   %Biggest in the window
            peak=match(end,i);
            active=1;
            k=1;
        end
    else
        k=k+1;
    end
    if k>window
        if active==1
            if peak>=threshold
                spot(sp,1)=peak;
                spot(sp,2)=(i-k);   %Take k away to know the exact point that had the maximum
                sp=sp+1;
                active=0;
                %peak=-1000;
                peak=-inf;
            end
            k=1;
        end
    end
    a=a+1;
    if a>window
        a=1;
    end
end

ret=spot;